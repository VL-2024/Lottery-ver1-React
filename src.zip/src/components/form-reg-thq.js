import React from 'react'

import './form-reg-thq.css'

const FormRegTHQ = (props) => {
  return <div className="form-reg-thq-container"></div>
}

export default FormRegTHQ
