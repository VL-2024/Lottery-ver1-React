import React from 'react'

import './sign-in-v2.css'

const SignInV2 = (props) => {
  return <div className="sign-in-v2-container"></div>
}

export default SignInV2
